package com.library.utilities;

import com.library.exception.BookNameException;

public class Utilities {
	public static void nameVAlidation(String bookName)throws BookNameException  {
		String pattern = "^[A-Za-z]$";
		if(!bookName.matches(pattern)) {
			throw new BookNameException("name can only alphabets");
		

		}
	}

}
