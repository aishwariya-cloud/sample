package com.library.dao;

import java.awt.List;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.library.model.Books;



public class BooksDAO {

	public static Connection connectToDB() {
		Connection connection = null;
		// Step 1: Register the driver.
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");

			// Step 2: Create connection
			connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "scott", "admin");
			return connection;
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}

	}

	public static void addBook(Books book) {
	
		// Step 3: Create statement

		try {
			// Statement stmt = connectToDB().createStatement();
			Connection con=connectToDB();
			PreparedStatement stmt = con.prepareStatement("insert into books values(?,?,?,?)");
			stmt.setInt(1, book.getBookId());
			stmt.setString(2, book.getBookName());
			stmt.setString(3, book.getBookAuthor());
			stmt.setDouble(4, book.getBookPrice());
			// Step 4: Execute SQL Query
			int affectedRows = stmt.executeUpdate();
			System.out.println("Affected rows " + affectedRows);
			
			//Step 5:Close Connection
			con.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	
	
	public static ArrayList<Books> displayBooks()
	{
		ArrayList<Books> bookList=new ArrayList<Books>();
		try {
			
			// Statement stmt = connectToDB().createStatement();
			Connection con=connectToDB();
			PreparedStatement stmt = con.prepareStatement("select *from books");
			
			// Step 4: Execute SQL Query
			ResultSet rs=stmt.executeQuery();
			while(rs.next())
			{
				Books book=new Books();
				book.setBookId(rs.getInt(1));
				book.setBookName(rs.getString(2));
				book.setBookAuthor(rs.getString(3));
				book.setBookPrice(rs.getDouble(4));
				bookList.add(book);
			}
			//Step 5:Close Connection
			con.close();
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return bookList;
		
	}
	public static ArrayList<Books> searchBooks(String bookName) {
		
		// Step 3: Create statement
		ArrayList<Books> booksList = new ArrayList<Books>();

		try {
			// Statement stmt = connectToDB().createStatement();
			Connection con=connectToDB();
			PreparedStatement stmt = con.prepareStatement("select * from Books where bookName=?");
			stmt.setString(1, bookName);
			
			// Step 4: Execute SQL Query
			ResultSet rs=stmt.executeQuery();
			while(rs.next())
			{
				Books book1=new Books();
				book1.setBookId(rs.getInt(1));
				book1.setBookName(rs.getString(2));
				book1.setBookAuthor(rs.getString(3));
				book1.setBookPrice(rs.getDouble(4));
				booksList.add(book1);
			}
			//Step 5:Close Connection
			con.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
return booksList;
	}
	

}