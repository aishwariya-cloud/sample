package com.library.services;

import java.util.ArrayList;
import java.util.List;

import com.library.dao.BooksDAO;
import com.library.exception.BookNameException;
import com.library.model.Books;
import com.library.utilities.Utilities;



	public class BookImpl implements BooksInterface{
		
		
		//BookImpl b=new BookImpl();
		
		@Override
		public void addBooks(String bookName,String bookPrice,String authorName)
		{
			
			Books book=new Books();
			//int bookId=id;
			//book.set
			book.setBookId(Books.getCounter());
			//String bookName=name;
			book.setBookName(bookName);
			try {
				Utilities.nameVAlidation(bookName);
			} catch (BookNameException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}
			//String bookPrice=price;
			book.setBookPrice(Double.parseDouble(bookPrice));
			//String bookAuthor=author;
			book.setBookAuthor(authorName);
			BooksDAO.addBook(book);
			
			
		}
		
		
		@Override
		public ArrayList<Books> displayBooks() {
			// TODO Auto-generated method stub
			return BooksDAO.displayBooks();
			
		}


		public ArrayList<Books> searchBooks(String bookName) {
			// TODO Auto-generated method stub
			return BooksDAO.searchBooks(bookName);
		}
		
					
	}