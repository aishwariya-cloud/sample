package com.library.services;

import java.util.ArrayList;
import java.util.List;

import com.library.model.Books;

public interface BooksInterface {
	
	public void addBooks(String bookName,String bookPrice,String authorName);
	public ArrayList<Books> displayBooks();
	public ArrayList<Books> searchBooks(String bookName);
}

