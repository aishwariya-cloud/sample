package com.deloitte.library.main;
import java.util.*;

import com.library.exception.BookNameException;
import com.library.model.Books;
import com.library.services.BookImpl;
import com.library.utilities.Utilities;

public class LibraryDemo {

	public static void main(String arg[]) {
		Scanner sc = new Scanner(System.in);
		String option;
		//Books book = new Books();
		BookImpl booksImpl = new BookImpl();
		List<Books> bookslist=new ArrayList<Books>();
		
		while (true) {
			System.out.println("1. ADD BOOK " + "\n 2.DISPLAY BOOK" + "\n 3.search"+"\n 4.EXIT" );
			option = sc.next();
			//System.out.println("Enter no:of books");
			//int num = sc.nextInt();
			switch (option) {
			case "1":
				
			
				
				System.out.println("Enter book name");
				String bookName = sc.next();
				

				System.out.println("Enter book price");
				String bookPrice = sc.next();

				System.out.println("Enter book author");
				String bookAuthor = sc.next();
				 
			
			booksImpl.addBooks(bookName, bookPrice, bookAuthor);
				
			
				break;

			case "2":
				
				 bookslist = booksImpl.displayBooks();
				for(Books book:bookslist)
				{
					System.out.println(book);
				}
			break;
			case "3":
				System.out.println("enter book for search");
				String searchBookName = sc.next();
				bookslist = booksImpl.searchBooks(searchBookName);
				for(Books book:bookslist)
				{
					System.out.println(book);
				}
			
			case "4":System.exit(0);
			break;

			}

		}

	}

}
