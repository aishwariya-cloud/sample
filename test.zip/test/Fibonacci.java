package test;

public class Fibonacci {
	public static void main(String args[]) {
		int num1=0;
		int num2=1;
		int temp;
		int count=10;
		for(int i=2;i<=count;i++) {
			temp=num1+num2;
			num1=num2;
			num2=temp;
			System.out.println("number:"+temp);
			
			}
		
	}
}
	


