package test;
import java.util.Scanner;

public class Even {
	public static void main(String args[]) {
		int num;
		Scanner s = new Scanner(System.in);
		System.out.println("enter number:");
		num = s.nextInt();
		if(num%2 == 0) {
			System.out.println("Enter number is even");
		}
		else {
			System.out.println("Enter number is odd");
		}
		
	}

}
