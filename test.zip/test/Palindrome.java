package test;

import java.util.Scanner;

public class Palindrome {
	public static void main(String args[]) {
		int number,temp,i;
		int sum =0;
		Scanner s=new Scanner(System.in);
		System.out.println("Enter number:");
		number = s.nextInt();
		temp = number;
		while(number>0) {
			i =number%10;
			sum =(sum*10)+i;
			number =number/10;
			
		}
		if(temp==sum) {
			System.out.println("Entered number is palindrome");
		}
		else {
			System.out.println("Entered number is not palidrome");
		}
		
		
	}

}
